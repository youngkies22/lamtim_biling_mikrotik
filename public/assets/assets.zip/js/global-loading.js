/**
 * Global Loading Progress Manager - Fixed Version
 */
(function () {
  'use strict';

  class GlobalLoading {
    constructor() {
      this.isLoading = false;
      this.loadingElement = null;
      this.progressElement = null;
      this.pageProgressElement = null;
      this.currentProgress = 0;
      this.targetProgress = 0;
      this.progressInterval = null;
      this.initialized = false;
      this.autoLoadingEnabled = false; // ✅ DEFAULT OFF untuk semua halaman
    }

    init() {
      if (this.initialized) return;

      // Wait for DOM to be ready
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => this.setup());
      } else {
        this.setup();
      }
    }

    setup() {
      // Create loading elements
      this.createLoadingElements();

      // Bind events hanya jika enabled
      this.bindEvents();

      this.initialized = true;

      // ✅ TIDAK auto show loading lagi (karena default OFF)
    }

    createLoadingElements() {
      // Full page loading overlay
      const overlay = document.createElement('div');
      overlay.className = 'global-loading-overlay fade-in';
      overlay.innerHTML = `
        <div class="loading-spinner"></div>
        <div class="loading-progress-container">
          <div class="loading-progress-bar">
            <div class="loading-progress-fill"></div>
            <div class="loading-progress-animated"></div>
          </div>
        </div>
        <div class="loading-text">Memuat halaman...</div>
      `;

      this.loadingElement = overlay;
      this.progressElement = overlay.querySelector('.loading-progress-fill');

      // Top page progress bar
      const pageProgress = document.createElement('div');
      pageProgress.className = 'page-loading-bar';
      this.pageProgressElement = pageProgress;

      // Append to body
      document.body.appendChild(overlay);
      document.body.appendChild(pageProgress);
    }

    bindEvents() {
      // ✅ Hanya bind events jika auto loading enabled
      if (!this.autoLoadingEnabled) return;

      // Show loading on page unload/navigation
      this.beforeUnloadHandler = () => {
        this.show('Memuat halaman...');
      };
      window.addEventListener('beforeunload', this.beforeUnloadHandler);

      // Hide loading when page is fully loaded
      this.loadHandler = () => {
        setTimeout(() => {
          this.hide();
        }, 800);
      };
      window.addEventListener('load', this.loadHandler);

      // AJAX loading for jQuery (delayed binding)
      this.bindJQueryEvents();

      // Fetch API interceptor
      this.bindFetchInterceptor();
    }

    bindJQueryEvents() {
      if (!this.autoLoadingEnabled) return;

      // Check for jQuery periodically and bind when available
      const checkJQuery = () => {
        if (typeof $ !== 'undefined' && $.fn) {
          $(document).ajaxStart(() => {
            this.showPageProgress();
          });

          $(document).ajaxStop(() => {
            this.hidePageProgress();
          });

          $(document).ajaxError(() => {
            this.hidePageProgress();
          });
        } else {
          setTimeout(checkJQuery, 100);
        }
      };

      checkJQuery();
    }

    bindFetchInterceptor() {
      if (!this.autoLoadingEnabled) return;

      if (typeof window.fetch === 'function') {
        const originalFetch = window.fetch;
        window.fetch = (...args) => {
          this.showPageProgress();
          return originalFetch(...args).finally(() => {
            this.hidePageProgress();
          });
        };
      }
    }

    // ✅ Method untuk enable auto loading (harus dipanggil manual)
    enableAutoLoading() {
      this.autoLoadingEnabled = true;
      this.bindEvents(); // Re-bind events

      // Show initial loading jika page masih loading
      if (document.readyState !== 'complete') {
        this.showPageLoading();
      }
    }

    disableAutoLoading() {
      this.autoLoadingEnabled = false;
      this.unbindEvents();
    }

    unbindEvents() {
      if (this.beforeUnloadHandler) {
        window.removeEventListener('beforeunload', this.beforeUnloadHandler);
      }
      if (this.loadHandler) {
        window.removeEventListener('load', this.loadHandler);
      }
    }

    show(text = 'Memuat...', progress = 0) {
      if (!this.initialized) {
        this.init();
        setTimeout(() => this.show(text, progress), 50);
        return;
      }

      if (this.isLoading) return;

      this.isLoading = true;
      this.currentProgress = 0;
      this.targetProgress = progress;

      // Update text
      const textElement = this.loadingElement.querySelector('.loading-text');
      if (textElement) {
        textElement.textContent = text;
      }

      // Show overlay
      this.loadingElement.style.display = 'flex';
      this.loadingElement.classList.remove('fade-out');
      this.loadingElement.classList.add('fade-in');

      // Animate progress
      this.animateProgress();
    }

    hide() {
      if (!this.isLoading || !this.loadingElement) return;

      this.isLoading = false;

      // Clear progress interval
      if (this.progressInterval) {
        clearInterval(this.progressInterval);
      }

      // Hide with animation
      this.loadingElement.classList.remove('fade-in');
      this.loadingElement.classList.add('fade-out');

      setTimeout(() => {
        if (this.loadingElement) {
          this.loadingElement.style.display = 'none';
          if (this.progressElement) {
            this.progressElement.style.width = '0%';
          }
        }
      }, 300);
    }

    updateProgress(progress, text = null) {
      if (!this.initialized) return;

      this.targetProgress = Math.min(100, Math.max(0, progress));

      if (text) {
        const textElement = this.loadingElement.querySelector('.loading-text');
        if (textElement) {
          textElement.textContent = text;
        }
      }
    }

    animateProgress() {
      if (this.progressInterval) {
        clearInterval(this.progressInterval);
      }

      this.progressInterval = setInterval(() => {
        if (this.currentProgress < this.targetProgress) {
          this.currentProgress += 2;
          if (this.progressElement) {
            this.progressElement.style.width = this.currentProgress + '%';
          }
        } else if (this.currentProgress >= 100) {
          clearInterval(this.progressInterval);
        }
      }, 50);
    }

    showPageLoading() {
      this.show('Memuat halaman...', 0);

      const loadingSteps = [
        { progress: 30, text: 'Memuat assets...', delay: 200 },
        { progress: 60, text: 'Memuat konten...', delay: 300 },
        { progress: 90, text: 'Menyelesaikan...', delay: 200 },
        { progress: 100, text: 'Selesai!', delay: 100 }
      ];

      loadingSteps.forEach((step, index) => {
        setTimeout(() => {
          this.updateProgress(step.progress, step.text);
          if (step.progress === 100) {
            setTimeout(() => this.hide(), 200);
          }
        }, step.delay * (index + 1));
      });
    }

    showPageProgress() {
      if (!this.pageProgressElement) return;

      this.pageProgressElement.style.width = '30%';

      setTimeout(() => {
        if (this.pageProgressElement) {
          this.pageProgressElement.style.width = '70%';
        }
      }, 200);
    }

    hidePageProgress() {
      if (!this.pageProgressElement) return;

      this.pageProgressElement.style.width = '100%';

      setTimeout(() => {
        if (this.pageProgressElement) {
          this.pageProgressElement.style.width = '0%';
        }
      }, 300);
    }

    showWithSteps(steps) {
      if (!steps || steps.length === 0) return;

      this.show(steps[0].text, 0);

      steps.forEach((step, index) => {
        setTimeout(() => {
          this.updateProgress(step.progress, step.text);
          if (step.progress >= 100) {
            setTimeout(() => this.hide(), 500);
          }
        }, step.delay * index);
      });
    }
  }

  // Initialize global loading instance
  const globalLoading = new GlobalLoading();

  // Expose to window for manual usage
  window.GlobalLoading = globalLoading;

  // Auto initialize
  globalLoading.init();
})();
